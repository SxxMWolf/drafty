// Minimal service worker to satisfy MV3 background requirement.
// Keep empty unless background logic is needed.
